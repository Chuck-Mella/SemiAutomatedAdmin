# updates-automation
A collection of scripts related to the automation of software updates for WSUS and ConfigMgr
