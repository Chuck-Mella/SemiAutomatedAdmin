﻿RegGetValue -Key "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion" -Value ReleaseId -GetValue GetStringValue -ErrorAction SilentlyContinue


