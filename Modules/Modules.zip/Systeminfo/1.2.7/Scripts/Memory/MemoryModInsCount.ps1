$count=0
$Win32_PhysicalMemory | foreach {$count++}
$count