﻿Function Get-AdminEvents
{
    <#
        .SYNOPSIS
            Retrieves eventlogs using Get-WinEvent

        .DESCRIPTION
            Get-AdminEvents uses Get-WinEvent to retrive Critical, Error, and Warning events from specified log names.
            Default Properties:  MachineName, Logname, ProviderName, LevelDisplayName, ID, UserID, TimeCreated

        .PARAMETER ComputerNames (Req'd)
            You may enter multiple computer names using a comma as the delimiter.

        .PARAMETER LogNames (Req'd) 
            You may enter multiple log names using a comma as the delimiter.

        .PARAMETER IDs 
            You may enter multiple ID numbers using a comma as the delimiter.

        .PARAMETER srchStart (Req'd)
            Date/Time to begin search at (if specifying time, you must use the format "M/d/y HH:mm"

        .PARAMETER srchInterval
            Defines interval length. Allowed values are 'Sec','Min','Hour','Day','Week'.

        .PARAMETER srchLength
            Number of intervals to retrieve (e.g. -srchInterval 'Day' -srchLength 5 returns 5 days
            of logs from the srchStart date.

        .PARAMETER All (Used with srchStart)
            Retrieves all the logs from the srchStart to the current day.

        .PARAMETER Path
            Path for the EventLogs and the ErrorLog

        .PARAMETER Output
            Enable saving the EventLogs and ErrorLog using the defaults.

        .EXAMPLE:
            Get-AdminEvents -ComputerName 'DC1' -LogNames Security -IDs 4720 -All -srchStart (Get-date).AddDays(-10) -Output

            
            Retrieves and saves all 4720 events from the DC1 Security log for the past 24 hours.

        .EXAMPLE:
            Get-AdminEvents -Lognames 'System' -srchStart (Get-date).AddDays(-30) -srchLength 4 -Output
            
            Retrieves 4 days of entries from the System log start 30 days ago.
    #>
    [Cmdletbinding()]
    Param
    (
        [Parameter(Mandatory=$false,ValueFromPipeline=$true)] [array]$ComputerName = (& HostName),
        [Parameter(Mandatory=$true,ValueFromPipeline=$true)] [array]$LogNames,
        [Parameter(Mandatory=$false,ValueFromPipeline=$true)] [array]$IDs,
        [Parameter(Mandatory=$true,ValueFromPipeline=$true)] [datetime]$srchStart,
        [ValidateSet('Sec','Min','Hour','Day','Week')] [string]$srchInterval = 'Day',
        [int]$srchLength = 1,
        [switch]$All,
		[Parameter(Mandatory=$false)][ValidateNotNullOrEmpty()]
		    [ValidateScript({Test-Path $_ -PathType 'Container'})][string]$Path="$env:UserProfile\Desktop\evtLogs",
        [switch]$Output
    )
    Begin
    {
        Function Dec64 { Param($a) $b = [System.Text.Encoding]::ASCII.GetString([System.Convert]::FromBase64String($a));Return $b }
        $evtTimeSpans = [Ordered]@{
            Sec = 1000
            Min = 60000 # x60
            Hour = 3600000 # x60
            Day = 86400000 # x24
            Week = 604800000 # x7
            }
        $evtTimeSpans = New-Object -TypeName PSObject -Property $evtTimeSpans
        $evtQueries = [Ordered]@{
            GPOAudits = (Dec64 'PFF1ZXJ5TGlzdD4NCiAgPFF1ZXJ5IElkPSIwIiBQYXRoPSJTZWN1cml0eSI+DQogICAgPFNlbGVjdCBQYXRo
                PSJTZWN1cml0eSI+KltTeXN0ZW1bKEV2ZW50SUQ9NTEzNiBvciBFdmVudElEPTUxMzcgb3IgRXZlbnRJRD01MTQxKSBhbmQgVGltZUNy
                ZWF0ZWRbdGltZWRpZmYoQFN5c3RlbVRpbWUpICZsdDs9IDI1OTIwMDAwMDBdXV08L1NlbGVjdD4NCiAgPC9RdWVyeT4NCjwvUXVlcnlM
                aXN0Pg==') # Last 30 Days
            GPOTSing = (Dec64 'PFF1ZXJ5TGlzdD4NCiAgPFF1ZXJ5IElkPSIwIiBQYXRoPSJBcHBsaWNhdGlvbiI+DQogICAgPFNlbGVjdCBQY
                XRoPSJBcHBsaWNhdGlvbiI+KltTeXN0ZW1bKEV2ZW50SUQ9NDA5OCldXTwvU2VsZWN0Pg0KICA8L1F1ZXJ5Pg0KPC9RdWVyeUxpc3Q+') # Troubleshooting
            }
        $evtQueries = New-Object -TypeName PSObject -Property $evtQueries
        # Set Start & End times
        $starttime = (Get-Date $srchStart)
        If ($all)
        {
            $endtime = (Get-Date)
        }
        Else
        {
            $endtime = $starttime.AddMilliSeconds($srchLength * $evtTimeSpans.$srchInterval)
        }
        $filedate =  "{0:yyyy-MM-dd}" -f $starttime
    }
    Process
    {
        ForEach ($logname in $lognames)
        {
            # Setup Event Search FilterHash
            If ($logname -eq 'Security'){ $fltrHash = @{Logname="$logname";StartTime=$starttime;EndTime=$endtime} }
            Else  { $fltrHash = @{Logname="$logname";StartTime=$starttime;EndTime=$endtime;Level=1,2,3} }
            If ($IDs -ne $null){ $fltrHash.Add('ID',$IDs) }
            ForEach ($computer in $computername)
            {
                $cmp = [string]$computer
                Try
                {    
                    $events = Get-WinEvent -ComputerName $cmp -FilterHashtable $fltrHash -ErrorAction Stop
                    $rptEvents = $events | Select-Object RecordID,MachineName,Logname,ProviderName,LevelDisplayName,ID,Message,UserID,TimeCreated
                    If ($output) {$rptEvents | Export-Csv "$path\$cmp`_$Logname.$filedate.Event.Logs.csv" -NoTypeInformation -Append} #If
                    Else {$rptEvents} #Else
                }
                Catch
                {
                    Write-Warning "Computer: $($cmp.toupper())   Log: $($logname.toupper())   Error: $($_.exception.message)"
                    If ($output)
                    {
                        $props = @{'Computer'=$($cmp.toupper());
                            'Log'=$($logname.toupper());
                            'Error'=$($_.Exception.Message)
                            } #props
                        $obj = New-Object -TypeName PSObject -Property $props
                        $obj | Export-Csv "$path\$cmp`_$Logname.$filedate.Error.Log.csv" -Append -NoTypeInformation
                    }
                }
            }
        }
    }
    End
    {}
}

Function Get-EvtLogTag
{
	    Param (
        $logName = 'GPOAudits',
        $logSrc = "GPScripts",
        $logEvtID = 7777,
        $rsltMax = 1
        )
    # Set Timeframe
    $Mark = Get-EventLog -LogName $logName -InstanceID $logEvtID -Source $logSrc -newest $rsltMax
    Switch ($Mark){
        ""      {$lstMark = (Get-Date).AddDays(-1)} #Today minus one if no tag found
        Default {$lstMark = $Mark.TimeWritten}
        } #Switch
    Return $lstMark

}

Function Set-EVTSource
{
    # Create eventlog source if it does not exist
    Param ( $Src="AdminScripts", $Log="Application", [switch]$Del )
    If ([bool]((whoami /all) -match 'S-1-16-12288') -eq $false){ Write-Warning "Elevated Credentials Required!"; Break }
    Switch ($Del){
        $true   { [System.Diagnostics.EventLog]::DeleteEventSource("$src") }
        default {
            If ( [System.Diagnostics.EventLog]::Exists("$Log") -eq $false ){ Write-Warning "Specified log [$Log] does not exist."; Break }
            $evtSrc = $False; $evtSrc = $(Try { [System.Diagnostics.EventLog]::SourceExists("$Src") } Catch { $false })
            If ($evtSrc -eq  $False){ [System.Diagnostics.EventLog]::CreateEventSource("$Src","$Log") }
            Else { Write-Warning "Specified source [$Src] already exists."; Break }
            }
        } #sw Del

}

Function New-ScriptEvent
{
	    <#
        .SYNOPSIS
           Log to a file in a format that can be read by Trace32.exe / CMTrace.exe 

        .DESCRIPTION
           Write a line of data to a script log file in a format that can be parsed by Trace32.exe / CMTrace.exe

           The severity of the logged line can be set as:

                1 - Information
                2 - Warning
                3 - Error

           Warnings will be highlighted in yellow. Errors are highlighted in red.

           The tools to view the log:

           SMS Trace - http://www.microsoft.com/en-us/download/details.aspx?id=18153
           CM Trace - Installation directory on Configuration Manager 2012 Site Server - <Install Directory>\tools\

        .EXAMPLE
           Log-ScriptEvent c:\output\update.log "Application of MS15-031 failed" Apply_Patch 3

           This will write a line to the update.log file in c:\output stating that "Application of MS15-031 failed".
           The source component will be Apply_Patch and the line will be highlighted in red as it is an error 
           (severity - 3).
    #>
    #Define and validate parameters
    [CmdletBinding()]
    Param(
            #Path to the log file
            [parameter(Mandatory=$True)] [String]$NewLog,
            #The information to log
            [parameter(Mandatory=$True)] [String]$Value,
            #The source of the error
            [parameter(Mandatory=$True)] [String]$Component,
            #The severity (1 - Information, 2- Warning, 3 - Error)
            [parameter(Mandatory=$True)] [ValidateRange(1,3)] [Single]$Severity
            )
    #Obtain UTC offset
    $DateTime = New-Object -ComObject WbemScripting.SWbemDateTime 
    $DateTime.SetVarDate($(Get-Date))
    $UtcValue = $DateTime.Value
    $UtcOffset = $UtcValue.Substring(21, $UtcValue.Length - 21)
    #Create the line to be logged
    $LogLine =  "<![LOG[$Value]LOG]!>" +`
                "<time=`"$(Get-Date -Format HH:mm:ss.fff)$($UtcOffset)`" " +`
                "date=`"$(Get-Date -Format M-d-yyyy)`" " +`
                "component=`"$Component`" " +`
                "context=`"$([System.Security.Principal.WindowsIdentity]::GetCurrent().Name)`" " +`
                "type=`"$Severity`" " +`
                "thread=`"$([Threading.Thread]::CurrentThread.ManagedThreadId)`" " +`
                "file=`"`">"
    #Write the line to the passed log file
    Add-Content -Path $NewLog -Value $LogLine

}

Function Search-EventLogs
{
	<#
        Search-EventLogs -LogName System -ComputerName localhost -STime (get-date 6/1/22) -ETime (get-date 6/8/22) | Out-GridView
        Search-EventLogs -LogName Application -ComputerName localhost -STime (get-date 6/1/22) -ETime (get-date 6/8/22) | Out-GridView
        Search-EventLogs -LogName Security -ComputerName localhost -STime (get-date 6/1/22) -ETime (get-date 6/8/22) | Out-GridView
        Search-EventLogs -LogName Setup -ComputerName localhost -STime (get-date 6/1/22) -ETime (get-date 6/8/22) | Out-GridView
        Search-EventLogs -ComputerName localhost -Provider 'Microsoft-Windows-GroupPolicy' -save
    #>
    Param (
        [Alias("LogName")][String]$Log = "System",
        [Alias("ComputerName")][String]$Cmp = "$($ENV:ComputerName)",
        [DateTime]$STime = (Get-Date).AddDays(-1),
        [DateTime]$ETime = (Get-Date),
        [String]$eType,
        [String]$Provider,
        [INT]$Max,
        [switch]$Save
        )
    $OS = (Get-CimInstance win32_operatingsystem -Cn $Cmp)
    $OSV = ($OS.Version.Split('.')[0])
    # $OSV = 8 
        If ($OSV -lt 06){ #.Caption "(XP|2000|2003)" 
            Write-Host "lt6"
            $evtQ = Get-EventLog -LogName $Log -ComputerName $Cmp -After $STime.AddHours(1) -Before $ETime.AddHours(1) -Newest $Max
            }
        ElseIf (($OSV -gt 5) -and ($OSV -le 8)){ #.Caption "(Vista|7|2008|2012)"
            Write-Host "5-8"
            $evtQ = Get-WinEvent -ComputerName $Cmp -FilterHashtable @{LogName=$Log;StartTime=$STime;EndTime=$ETime} -MaxEvents $Max
            }
        ElseIf (($OSV -gt 5) -AND ($Provider)) {
            Write-Host "gt5 & Prov"
            $evtQ = (Get-WinEvent -ComputerName $Cmp -ListProvider $Provider).Events
            }
    }
    $wkDir = "$env:UserProfile\Desktop"
    If (!$evtQ){ Write-Warning "No Data returned.";Break }
    Else {
        If ($Save){
            $rstFileName = "$wkDir\EvtQry_$Cmp`_$Log.xml"
            $tmpFile = [io.path]::GetTempFileName()
            $evtQ|Export-Clixml $tmpFile
            Move-Item -Force -Path $tmpFile -Destination $rstFileName
            II $rstFileName
            } #If Save
        Else { Return $evtQ }
        } #Else

}

Function Set-EventLogTag
{
    Param
    (
        $trgComp,
        $logName,
        $logEvtID = 7777,
        $logSrc
    )
    If ([String]::IsNullOrEmpty($trgComp) -eq $true){ $trgComp = $env:ComputerName }
    If ([String]::IsNullOrEmpty($logName) -eq $true){ $logName = 'Application' }
    If ([String]::IsNullOrEmpty($trgComp) -eq $true){ $trgComp = $env:ComputerName }
    Write-EVTLog -trgComp $env:ComputerName -logName $logName `
                 -logSrc $logSrc -logEvtID $logEvtID -logEvtType 'Information' `
                 -logEvtCat 1 -logMssg 'Tag Event for tracking.'

}

Function Set-EvtXMLQuery
{
	    #  $qry = i-Set-EvtXMLQuery -EvtIDs @(13508,13509,13511,13522,13526,13548,13557,13567,13568) -EvtLog 'File Replication Service' -EvtComp $DCs[1]
    #  Get-WinEvent -FilterXml $qry -ComputerName $DCs[1]
    Param (
        [String]$EvtComp = $env:COMPUTERNAME,
        [String]$EvtLog = "Application",
        [Array]$EvtSrc, # e.g. @('.NET Runtime','.NET Runtime Optimization Service','ACPI','Enterprise Vault CryptoModule')
        [Array]$EvtLvl, # e.g. @(0,1,2,3,4,5)
        #band/keyword
        [Array]$EvtIDs, # e.g. @(1,3,'5-99',-76)
        [DateTime]$trgTime = (Get-Date),
        $EvtRng = "-1", # Last hour as default
        [Parameter(ParameterSetName="seta")][Switch]$Before,
        [Parameter(ParameterSetName="seta")][Switch]$After,
        [Parameter(ParameterSetName="setb")][Switch]$Last,
        [Parameter(Mandatory=$true,ParameterSetName="setb")]
            [ValidateSet('Minute','Hour','Day','Week')]$EvtLst,
        [Parameter(ParameterSetName="setb")][Int]$lstMultiplier = 1,
        $EvtSup # e.g. @(99,75)
        )
    #region Build header
        $EvtXml = "<QueryList>`n`t<Query Id=`"0`" Path=`"$EvtLog`">`n`t`t<Select Path=`"$EvtLog`">`n"
    #endregion
    #region Set Source(s) and Computername
        If ($EvtSrc){
            If ($EvtSrc -is [Array]){
                $tmpEvt = "`t`t`t`t*[System[Provider["
                For($i=0;$i-lt$EvtSrc.Count;$i++){
                    $tmpEvt = $tmpEvt + "@Name=`'$($EvtSrc[$i])`'"
                    If($i -lt ($EvtSrc.Count - 1)){$tmpEvt = $tmpEvt + " or "}
                    } #For
                    $tmpEvt = $tmpEvt + "] and`n`t`t`t`t(Computer=`'$EvtComp`') and`n"
                    $EvtXml = $EvtXml + $tmpEvt
                } #If
            Else {
                $EvtXml = $EvtXml + "`t`t`t`t*[System[Provider[@Name=`'$($EvtSrc)`' and`n`t`t`t`t(Computer=`'$EvtComp`') and`n"
                } #Else
            } #If
        Else {$EvtXml = $EvtXml + "`t`t`t`t*[System[(Computer=`'$EvtComp`') and`n"}
    #endregion
    #region Set Event Level(s)
        $EvtLvls = [Ordered]@{0 = 'Info';1 = 'Critical';2 = 'Error';3 = 'Warning';4 = 'Info';5 = 'Verbose'}
        If ($EvtLvl){
            If ($EvtLvl -is [Array]){
                $tmpEvt = "`t`t`t`t("
                For($i=0;$i-lt$EvtLvl.Count;$i++){
                    $tmpEvt = $tmpEvt + "Level=$($EvtLvl[$i])"
                    If($i -lt ($EvtLvl.Count - 1)){$tmpEvt = $tmpEvt + " or "}
                    } #For
                    $tmpEvt = $tmpEvt + ") and`n"
                    $EvtXml = $EvtXml + $tmpEvt
                } #If
            Else {
                $EvtXml = $EvtXml + "`t`t`t`t(Level=$($EvtLvl)) and`n"
                } #Else
            } #If
    #endregion
    #region STUB - Set Keyword(s) - `t`t`t`t(band(Keywords,41095346599755776)) and
    #endregion
    #region Set EventID(s)
        If ($EvtIDs){
            If ($EvtIDs -is [Array]){
                $EvtRMs = $EvtIDs|?{Function Set-EvtXMLQuery
{
	<CODE>
}


 -like "-*"}
                $EvtRMs | ForEach {$EvtSup += ((Function Set-EvtXMLQuery
{
	<CODE>
}


).toString()).Replace("-","")}
                $EvtIDs = $EvtIDs|?{Function Set-EvtXMLQuery
{
	<CODE>
}


 -notlike "-*"}
                $tmpEvt = "`t`t`t`t(" #EventID=1 or EventID=3 or (EventID &gt;= 5 and EventID &lt;= 99) ) and"
                For($i=0;$i-lt$EvtIDs.Count;$i++){
                    If ($EvtIDs[$i] -match "-"){
                        $hi = (($EvtIDs[2]).Split("-")| Measure -Max).Maximum
                        $lo = (($EvtIDs[2]).Split("-")| Measure -Min).Minimum
                        $tmpEvt = $tmpEvt + "(EventID &gt;= $lo and EventID &lt;= $hi)"
                        } #If
                    Else { $tmpEvt = $tmpEvt + "EventID=$($EvtIDs[$i])" } #Else
                    If ($i -lt ($EvtIDs.Count - 1)){$tmpEvt = $tmpEvt + " or "} #If
                    } #For
                $tmpEvt = $tmpEvt + ") and`n"
                $EvtXml = $EvtXml + $tmpEvt
                } #If
            Else { $EvtXml = $EvtXml + "`t`t`t`t(EventID=$EvtIDs) and`n" } #Else
            } #If
    #endregion
    #region Set Time(s)
        # Convert to GMT (UTC)
        $trgTime = ($trgTime).ToUniversalTime()
        # Format times to XML Query format
        $EvtTime = ("{0:yyyy-MM-ddTHH:mm:ss:fff}z" -f (Get-Date $trgTime))
        $EvtStrt = ("{0:yyyy-MM-ddTHH:mm:ss:fff}z" -f (Get-Date $trgTime).AddHours($EvtRng))
        $EvtEnd = $EvtTime
        # Add times to query
        If ($Before -and $After){
            $EvtXml = $EvtXml + "`t`t`t`tTimeCreated[@SystemTime&lt;=`'$EvtTime`' and TimeCreated[@SystemTime&gt;=`'$EvtTime`'"}
        ElseIf ($Before) {$EvtXml = $EvtXml + "`t`t`t`tTimeCreated[@SystemTime&lt;=`'$EvtTime`'"}
        ElseIf ($After) {$EvtXml = $EvtXml + "`t`t`t`tTimeCreated[@SystemTime&gt;=`'$EvtTime`'"}
        ElseIf ($Last) {
            Switch ($EvtLst){
                {'Minute'} {$lsRng = 60000;$gdAction='AddMinutes'}
                {'Hour'}   {$lsRng = 3600000;$gdAction='AddHours'}
                {'Day'}    {$lsRng = 86400000;$gdAction='AddDays'}
                {'Week'}   {$lsRng = 604800000;$gdAction='AddDays'}
                } #sw
            $EvtXml = $EvtXml + "`t`t`t`tTimeCreated[timediff(@SystemTime) &lt;=$($lsRng * $lstMultiplier)"
            } 
        Else { $EvtXml = $EvtXml.TrimEnd("and`n") } #Remove trailing 'and'     [regex]::Matches($EvtXml,"and`n$") 
    #endregion
    #region Set closing brackets and close the section
        $cb = "]" * [regex]::matches($EvtXml,"\[").Count
        $EvtXml = $EvtXml + "$($cb)`n`t`t</Select>`n"
    #endregion
    #region Set Suppressed EventID(s)
        If ($EvtSup){
            If ($EvtSup -is [Array]){
                $tmpEvt = "`t`t<Suppress Path=`"$EvtLog`">*[System[("
                For($i=0;$i-lt$EvtSup.Count;$i++){
                    $tmpEvt = $tmpEvt + "EventID=$($EvtSup[$i])"
                    If($i -lt ($EvtSup.Count - 1)){$tmpEvt = $tmpEvt + " or "}
                    } #For
                 $tmpEvt = $tmpEvt + ")]]</Suppress>`n"
                 $EvtXml = $EvtXml + $tmpEvt
               } #If
            Else {
                $EvtXml = $EvtXml + "`t`t<Suppress Path=`"$EvtLog`">*[System[(EventID=$EvtSup)]]</Suppress>`n"
                } #Else
            } #If
    #endregion
    # Close-out XML & display
        $EvtXml = $EvtXml + "`t</Query>`n</QueryList>`n"
        $EvtXml

}

Function Write-EVTLog
{
    # Write event to specified log
    Param
    (
        $trgComp = $env:ComputerName,
        [Parameter(Mandatory=$True)]$logName,
        [Parameter(Mandatory=$True)]$logSrc,
        [Parameter(Mandatory=$True)]$logEvtID,
        [Parameter(Mandatory=$False)]$logEvtType = 'Information',
        [Parameter(Mandatory=$False)]$logEvtCat = 1,
        [String]$logMssg
    )
    If ((Get-Host).version.Major -lt 2){ BREAK } #Min Requirements Check
    $Initiator = "`nInitiator: $($env:UserDomain)\$($env:UserName)"
    # Create eventlog entries
        # Create source if it does not exist
        If (![System.Diagnostics.EventLog]::SourceExists($logSrc)){
            [System.Diagnostics.EventLog]::CreateEventSource($logSrc,$logName)
            }
    # Write event to specified log
        If (!$logMssg){$logMssg = "Tracking Event for Troubleshooting: $logSrc$Initiator"}
        Else {$logMssg = $logMssg + $Initiator}
        Write-EventLog -ComputerName $trgComp -logname $logName `
                       -source $logSrc -EventID $logEvtID `
                       -message "$logMssg" -EntryType $logEvtType `
                       -Category $logEvtCat  -ErrorAction Stop
}


Function Convert-Evt2XL{
	    Param(
        [Parameter(Position=0, Mandatory=$true)][ValidateNotNullOrEmpty()]
            [ValidateScript({Test-Path Function Convert-Evt2XL
{
	<CODE>
}


 -PathType 'Container'})][string]$Path="C:\Temp\Logs",
        $ComputerName
        )
    If (!$Function:ComputerName){
        $Function:ComputerName = Import-Csv $Path\ComputerNames.csv | Select -ExpandProperty ComputerName
        }
    # Get-AdminEvents -ComputerName $env:computername -LogNames 'application','system' -StartDay 1 -NumberOfDays 2 -Output
    # Select Files
        $events = Get-ChildItem -Path "$path\*Event.Logs.csv" | Select -Last 1
        $errors = Get-ChildItem -Path "$path\*Error.Log.csv" | Select -Last 1
    # Create Workbook
        $xlexcel8 = 56
        $xl = New-Object -ComObject excel.application
        $xl.visible = $true #$false
        $wb1 = $xl.workbooks.Add()
        $wb1s3 = $wb1.sheets | Where-Object {Function Convert-Evt2XL
{
	<CODE>
}


.Name -eq "Sheet3"}
        $wb1s2 = $wb1.sheets | Where-Object {Function Convert-Evt2XL
{
	<CODE>
}


.Name -eq "Sheet2"}
    $wb1s1 = $wb1.sheets | Where-Object {Function Convert-Evt2XL
{
	<CODE>
}


.Name -eq "Sheet1"}
    #create Event Log Worksheet
        $wb2 = $xl.Workbooks.Open($($events.Fullname), $null, $true)
        $wb2s1 = $wb2.sheets.item(1)
    #Create Error Log Worksheet
        If ($errors) {
            $wb3 = $xl.Workbooks.Open($($errors.FullName), $null, $true)
            $wb3s1 = $wb3.sheets.item(1)
            } #If
        $wb2s1.copy($wb1s1)
        If ($errors){
            $wb3s1.copy($wb1s2)
            } #If
    #Delete extraneous worksheets
        $wb1s3.delete()
        $wb1s2.delete()
        $wb1s1.delete()
    #Save as XLS, close open workbooks and delete original CSVs
        $wb1.saveas("$path\$($events.basename).xls",$xlexcel8)
        If ($errors) {
            $wb3.close($false)
            Remove-Item $errors
            } #If
        $wb2.close($false)
        Remove-Item $events
        $wb1.close($true)
        $xl.quit()

}

Function Add-EvtSource{
	<#
        .Synopsis
            Add/Remove specified Event Source(s) to the specified Event Log (Default is 'Application')

        .Description
            Performs logic test on Event sources. It will not add an existing Source nor delete a non-existing source.

        .Parameter Sources
            Source name(s) to be added.

        .Parameter Log
             Target Event Log (Default = 'Application')

        .Parameter Delete
            Remove specified Event Source(s) from the specified Event Log (Default is 'Application')

        .Example
            Add-EvtSource -Sources 'H2LWarningAdd-In'

            Adds a new event source 'H2LWarningAdd-In' to the Application log.

        .Example
            Add-EvtSource -Sources 'H2LWarningAdd-In' -Delete

            Removes the event source 'H2LWarningAdd-In' from the Application log.
    #>
    Param
    (
        [Parameter(mandatory=$true)][Array]$Sources,
        [String]$Log = 'Application',
        [switch]$Delete
    )
    $evt = [System.Diagnostics.EventLog]
    ForEach ($Source in $Sources)
    {
        Switch ($Delete)
        {
            $True   { If ($evt::SourceExists($Source)){ $evt::DeleteEventSource($Source) } }
            default { If (!($evt::SourceExists($Source))){ $evt::CreateEventSource($Source,$Log) } }
        }
    }
}

Export-ModuleMember -Function Get-AdminEvents,Get-EvtLogTag,Set-EVTSource,New-ScriptEvent,Search-EventLogs,Set-EventLogTag,Set-EvtXMLQuery,Write-EVTLog,Convert-Evt2XL,Add-EvtSource

